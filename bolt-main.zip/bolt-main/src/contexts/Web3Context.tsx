import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ethers } from 'ethers';
import { ERC20_ABI, AIM_STAKING_ABI, PANCAKESWAP_ROUTER_V2_ABI, PANCAKESWAP_FACTORY_ABI, PANCAKESWAP_PAIR_ABI } from '../contracts/abis';

// Contract addresses - Replace with actual deployed addresses
const CONTRACTS = {
  AIM_TOKEN: '0x0bF3BAcAF2442Ecb7545709960056dbDe23FD674', // Replace with actual AIM token address
  USDT_TOKEN: '0x55d398326f99059fF775485246999027B3197955', // USDT on BSC
  AIM_STAKING: '0x758CDCf3e09f654f9C4220f488770167e8a96f8B', // Replace with actual staking contract address
  WBNB: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', // WBNB on BSC
  PANCAKESWAP_ROUTER_V2: '0x10ED43C718714eb63d5aA57B78B54704E256024E', // PancakeSwap Router V2
  PANCAKESWAP_FACTORY: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73', // PancakeSwap Factory
};

interface UserStakeInfo {
  planId: number;
  amount: string;
  startTime: number;
  lastClaimTime: number;
  dailyReward: string;
  active: boolean;
  holdBonus: boolean;
  claimableRewards: string;
  remainingTime: number;
}

interface ReferralInfo {
  referrer: string;
  totalReferrals: number;
  totalEarnings: string;
}

interface StakingPlan {
  duration: number;
  totalReturn: number;
  active: boolean;
  amounts: string[];
  dailyRewards: string[];
}

interface PriceInfo {
  realTimePrice: number;
  contractPrice: number;
  lastUpdated: number;
  pairExists: boolean;
  usingPancakeSwap: boolean;
}

interface AimFundingInfo {
  contractBalance: string;
  totalFunded: string;
  totalDistributed: string;
  availableForRewards: string;
}

interface TransactionHistory {
  type: string;
  amount: number;
  date: string;
  status: string;
  txHash?: string;
  blockNumber?: number;
}

interface Web3ContextType {
  account: string | null;
  provider: ethers.BrowserProvider | null;
  signer: ethers.JsonRpcSigner | null;
  aimPrice: number;
  priceInfo: PriceInfo;
  aimFundingInfo: AimFundingInfo;
  isConnected: boolean;
  loading: boolean;
  isOwner: boolean;
  
  // Contract instances
  aimContract: ethers.Contract | null;
  usdtContract: ethers.Contract | null;
  stakingContract: ethers.Contract | null;
  
  // Balances
  aimBalance: string;
  usdtBalance: string;
  bnbBalance: string;
  
  // Staking data
  userStakeInfo: UserStakeInfo | null;
  referralInfo: ReferralInfo | null;
  totalStaked: string;
  totalUsers: number;
  stakingPlans: StakingPlan[];
  
  // Transaction history
  transactionHistory: TransactionHistory[];
  
  // Functions
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  switchToBSC: () => Promise<void>;
  
  // Contract functions
  stakeUSDT: (planId: number, amount: string, referrer?: string) => Promise<boolean>;
  claimRewards: () => Promise<boolean>;
  fundAimTokens: (amount: string) => Promise<boolean>;
  ownerFundAimTokens: (amount: string) => Promise<boolean>;
  updateContractAimPrice: () => Promise<boolean>;
  togglePancakeSwapPrice: (enabled: boolean) => Promise<boolean>;
  withdrawAimTokens: (amount: string) => Promise<boolean>;
  
  // Data fetching functions
  fetchUserData: () => Promise<void>;
  fetchGlobalData: () => Promise<void>;
  fetchBalances: () => Promise<void>;
  fetchAimFundingInfo: () => Promise<void>;
  fetchTransactionHistory: () => Promise<void>;
  getReferralLevelInfo: (level: number) => Promise<{ referrals: number; earnings: string }>;
  
  // Utility functions
  convertUsdtToAim: (usdtAmount: string) => string;
  convertAimToUsdt: (aimAmount: string) => string;
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined);

const BSC_CHAIN_ID = '0x38'; // BSC Mainnet
const BSC_RPC_URL = 'https://bsc-dataseed.binance.org/';

export const Web3Provider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [account, setAccount] = useState<string | null>(null);
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null);
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null);
  const [aimPrice, setAimPrice] = useState<number>(0.025);
  const [priceInfo, setPriceInfo] = useState<PriceInfo>({
    realTimePrice: 0.025,
    contractPrice: 0.025,
    lastUpdated: 0,
    pairExists: false,
    usingPancakeSwap: false,
  });
  const [aimFundingInfo, setAimFundingInfo] = useState<AimFundingInfo>({
    contractBalance: '0',
    totalFunded: '0',
    totalDistributed: '0',
    availableForRewards: '0',
  });
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [isOwner, setIsOwner] = useState<boolean>(false);
  
  // Contract instances
  const [aimContract, setAimContract] = useState<ethers.Contract | null>(null);
  const [usdtContract, setUsdtContract] = useState<ethers.Contract | null>(null);
  const [stakingContract, setStakingContract] = useState<ethers.Contract | null>(null);
  
  // Balances
  const [aimBalance, setAimBalance] = useState<string>('0');
  const [usdtBalance, setUsdtBalance] = useState<string>('0');
  const [bnbBalance, setBnbBalance] = useState<string>('0');
  
  // Staking data
  const [userStakeInfo, setUserStakeInfo] = useState<UserStakeInfo | null>(null);
  const [referralInfo, setReferralInfo] = useState<ReferralInfo | null>(null);
  const [totalStaked, setTotalStaked] = useState<string>('0');
  const [totalUsers, setTotalUsers] = useState<number>(0);
  const [stakingPlans, setStakingPlans] = useState<StakingPlan[]>([]);
  
  // Transaction history
  const [transactionHistory, setTransactionHistory] = useState<TransactionHistory[]>([]);

  // Utility functions for conversion
  const convertUsdtToAim = (usdtAmount: string): string => {
    const usdtValue = parseFloat(usdtAmount);
    if (usdtValue === 0 || aimPrice === 0) return '0';
    return (usdtValue / aimPrice).toFixed(6);
  };

  const convertAimToUsdt = (aimAmount: string): string => {
    const aimValue = parseFloat(aimAmount);
    if (aimValue === 0 || aimPrice === 0) return '0';
    return (aimValue * aimPrice).toFixed(6);
  };

  // Initialize contracts when signer is available
  useEffect(() => {
    if (signer) {
      initializeContracts();
    }
  }, [signer]);

  // Fetch data when connected
  useEffect(() => {
    if (isConnected && account && stakingContract) {
      fetchUserData();
      fetchGlobalData();
      fetchBalances();
      fetchAimFundingInfo();
      fetchTransactionHistory();
      checkOwnership();
      
      // Set up periodic data refresh
      const interval = setInterval(() => {
        fetchUserData();
        fetchGlobalData();
        fetchBalances();
        fetchAimFundingInfo();
        fetchTransactionHistory();
        fetchAimPrice();
      }, 30000); // Refresh every 30 seconds
      
      return () => clearInterval(interval);
    }
  }, [isConnected, account, stakingContract]);

  // Check if wallet is already connected
  useEffect(() => {
    checkConnection();
    fetchAimPrice();
  }, []);

  const initializeContracts = async () => {
    if (!signer) return;
    
    try {
      const aimContractInstance = new ethers.Contract(CONTRACTS.AIM_TOKEN, ERC20_ABI, signer);
      const usdtContractInstance = new ethers.Contract(CONTRACTS.USDT_TOKEN, ERC20_ABI, signer);
      const stakingContractInstance = new ethers.Contract(CONTRACTS.AIM_STAKING, AIM_STAKING_ABI, signer);
      
      setAimContract(aimContractInstance);
      setUsdtContract(usdtContractInstance);
      setStakingContract(stakingContractInstance);
      
      console.log('Contracts initialized successfully');
    } catch (error) {
      console.error('Error initializing contracts:', error);
    }
  };

  const checkConnection = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.listAccounts();
        
        if (accounts.length > 0) {
          const signer = await provider.getSigner();
          setProvider(provider);
          setSigner(signer);
          setAccount(accounts[0].address);
          setIsConnected(true);
        }
      } catch (error) {
        console.error('Error checking connection:', error);
      }
    }
  };

  const checkOwnership = async () => {
    if (!stakingContract || !account) return;
    
    try {
      const owner = await stakingContract.owner();
      setIsOwner(owner.toLowerCase() === account.toLowerCase());
    } catch (error) {
      console.error('Error checking ownership:', error);
      setIsOwner(false);
    }
  };

  const fetchAimPrice = async () => {
    try {
      let realTimePrice = 0.025; // Default fallback
      let contractPrice = 0.025; // Default fallback
      let pairExists = false;
      let usingPancakeSwap = false;

      if (stakingContract) {
        try {
          // Get price info from smart contract
          const priceInfoResult = await stakingContract.getPriceInfo();
          realTimePrice = parseFloat(ethers.formatEther(priceInfoResult[0]));
          contractPrice = parseFloat(ethers.formatEther(priceInfoResult[1]));
          usingPancakeSwap = priceInfoResult[2];
          pairExists = priceInfoResult[3];
          
          console.log('Price info from contract:', {
            realTimePrice,
            contractPrice,
            usingPancakeSwap,
            pairExists
          });
        } catch (error) {
          console.log('Could not fetch price info from contract, using fallback');
          // Use mock price with slight fluctuation as fallback
          realTimePrice = 0.025 + (Math.random() - 0.5) * 0.001;
          contractPrice = realTimePrice;
        }
      } else {
        // Use mock price with slight fluctuation as fallback
        realTimePrice = 0.025 + (Math.random() - 0.5) * 0.001;
        contractPrice = realTimePrice;
      }

      // Update price info
      const newPriceInfo: PriceInfo = {
        realTimePrice: Number(realTimePrice.toFixed(6)),
        contractPrice: Number(contractPrice.toFixed(6)),
        lastUpdated: Date.now(),
        pairExists,
        usingPancakeSwap,
      };

      setPriceInfo(newPriceInfo);
      
      // Use real-time price for display
      setAimPrice(newPriceInfo.realTimePrice);
      
    } catch (error) {
      console.error('Error in fetchAimPrice:', error);
      // Fallback to mock price
      const mockPrice = 0.025 + (Math.random() - 0.5) * 0.001;
      setAimPrice(Number(mockPrice.toFixed(6)));
      
      setPriceInfo({
        realTimePrice: Number(mockPrice.toFixed(6)),
        contractPrice: Number(mockPrice.toFixed(6)),
        lastUpdated: Date.now(),
        pairExists: false,
        usingPancakeSwap: false,
      });
    }
  };

  const fetchAimFundingInfo = async () => {
    if (!stakingContract) return;
    
    try {
      const fundingInfo = await stakingContract.getAimFundingInfo();
      setAimFundingInfo({
        contractBalance: ethers.formatEther(fundingInfo[0]),
        totalFunded: ethers.formatEther(fundingInfo[1]),
        totalDistributed: ethers.formatEther(fundingInfo[2]),
        availableForRewards: ethers.formatEther(fundingInfo[3]),
      });
    } catch (error) {
      console.error('Error fetching AIM funding info:', error);
    }
  };

  const fetchTransactionHistory = async () => {
    if (!stakingContract || !account || !provider) {
      console.log('🔍 fetchTransactionHistory: Missing requirements');
      return;
    }
    
    try {
      console.log('🔍 fetchTransactionHistory: Starting transaction history fetch for account:', account);
      
      const transactions: TransactionHistory[] = [];
      
      // Get current block number
      const currentBlock = await provider.getBlockNumber();
      const fromBlock = Math.max(0, currentBlock - 10000); // Look back 10000 blocks (~8 hours on BSC)
      
      console.log('🔍 fetchTransactionHistory: Querying from block', fromBlock, 'to', currentBlock);
      
      // Query Staked events where user is the staker
      try {
        const stakedFilter = stakingContract.filters.Staked(account, null, null, null);
        const stakedEvents = await stakingContract.queryFilter(stakedFilter, fromBlock, currentBlock);
        
        console.log('🔍 fetchTransactionHistory: Found', stakedEvents.length, 'staked events');
        
        for (const event of stakedEvents) {
          if (event.args) {
            const block = await provider.getBlock(event.blockNumber);
            transactions.push({
              type: 'Staking',
              amount: parseFloat(ethers.formatEther(event.args[2])), // amount in USDT
              date: new Date(block!.timestamp * 1000).toISOString().split('T')[0],
              status: 'Completed',
              txHash: event.transactionHash,
              blockNumber: event.blockNumber,
            });
          }
        }
      } catch (error) {
        console.error('🔍 fetchTransactionHistory: Error fetching staked events:', error);
      }
      
      // Query Claimed events where user is the claimer
      try {
        const claimedFilter = stakingContract.filters.Claimed(account, null, null);
        const claimedEvents = await stakingContract.queryFilter(claimedFilter, fromBlock, currentBlock);
        
        console.log('🔍 fetchTransactionHistory: Found', claimedEvents.length, 'claimed events');
        
        for (const event of claimedEvents) {
          if (event.args) {
            const block = await provider.getBlock(event.blockNumber);
            // Show AIM amount directly
            const aimAmount = parseFloat(ethers.formatEther(event.args[1]));
            
            transactions.push({
              type: 'Staking Reward',
              amount: aimAmount,
              date: new Date(block!.timestamp * 1000).toISOString().split('T')[0],
              status: 'Completed',
              txHash: event.transactionHash,
              blockNumber: event.blockNumber,
            });
          }
        }
      } catch (error) {
        console.error('🔍 fetchTransactionHistory: Error fetching claimed events:', error);
      }
      
      // Query ReferralPaid events where user is the referrer
      try {
        const referralFilter = stakingContract.filters.ReferralPaid(account, null, null, null);
        const referralEvents = await stakingContract.queryFilter(referralFilter, fromBlock, currentBlock);
        
        console.log('🔍 fetchTransactionHistory: Found', referralEvents.length, 'referral events');
        
        for (const event of referralEvents) {
          if (event.args) {
            const block = await provider.getBlock(event.blockNumber);
            // Show AIM amount directly
            const aimAmount = parseFloat(ethers.formatEther(event.args[3]));
            
            transactions.push({
              type: 'Referral Bonus',
              amount: aimAmount,
              date: new Date(block!.timestamp * 1000).toISOString().split('T')[0],
              status: 'Completed',
              txHash: event.transactionHash,
              blockNumber: event.blockNumber,
            });
          }
        }
      } catch (error) {
        console.error('🔍 fetchTransactionHistory: Error fetching referral events:', error);
      }
      
      // Sort transactions by block number (most recent first)
      transactions.sort((a, b) => (b.blockNumber || 0) - (a.blockNumber || 0));
      
      // Limit to most recent 20 transactions
      const limitedTransactions = transactions.slice(0, 20);
      
      console.log('🔍 fetchTransactionHistory: Processed', limitedTransactions.length, 'transactions');
      setTransactionHistory(limitedTransactions);
      
    } catch (error) {
      console.error('🔍 fetchTransactionHistory: Error fetching transaction history:', error);
      // Set empty array on error to avoid showing stale data
      setTransactionHistory([]);
    }
  };

  const updateContractAimPrice = async (): Promise<boolean> => {
    if (!stakingContract || !account) {
      throw new Error('Contract not initialized or wallet not connected');
    }

    if (!isOwner) {
      throw new Error('Only contract owner can update the price');
    }

    try {
      setLoading(true);

      // Use the real-time price from PancakeSwap
      const priceToUpdate = priceInfo.realTimePrice;
      const priceInWei = ethers.parseEther(priceToUpdate.toString());

      console.log('Updating contract price to:', priceToUpdate);
      const updateTx = await stakingContract.updateAimPrice(priceInWei);
      await updateTx.wait();

      console.log('Contract price updated successfully!');

      // Refresh price info
      await fetchAimPrice();

      return true;
    } catch (error: any) {
      console.error('Error updating contract price:', error);
      throw new Error(error.reason || error.message || 'Price update failed');
    } finally {
      setLoading(false);
    }
  };

  const togglePancakeSwapPrice = async (enabled: boolean): Promise<boolean> => {
    if (!stakingContract || !account) {
      throw new Error('Contract not initialized or wallet not connected');
    }

    if (!isOwner) {
      throw new Error('Only contract owner can toggle PancakeSwap pricing');
    }

    try {
      setLoading(true);

      console.log('Toggling PancakeSwap pricing to:', enabled);
      const toggleTx = await stakingContract.togglePancakeSwapPrice(enabled);
      await toggleTx.wait();

      console.log('PancakeSwap pricing toggled successfully!');

      // Refresh price info
      await fetchAimPrice();

      return true;
    } catch (error: any) {
      console.error('Error toggling PancakeSwap pricing:', error);
      throw new Error(error.reason || error.message || 'Toggle failed');
    } finally {
      setLoading(false);
    }
  };

  const fundAimTokens = async (amount: string): Promise<boolean> => {
    if (!stakingContract || !aimContract || !account) {
      throw new Error('Contracts not initialized or wallet not connected');
    }

    try {
      setLoading(true);

      const amountInWei = ethers.parseEther(amount);

      // First, check if user has enough AIM tokens
      const balance = await aimContract.balanceOf(account);
      if (balance < amountInWei) {
        throw new Error('Insufficient AIM balance');
      }

      // Check allowance
      const allowance = await aimContract.allowance(account, CONTRACTS.AIM_STAKING);

      // If allowance is insufficient, approve first
      if (allowance < amountInWei) {
        console.log('Approving AIM spending...');
        const approveTx = await aimContract.approve(CONTRACTS.AIM_STAKING, amountInWei);
        await approveTx.wait();
        console.log('AIM approved successfully');
      }

      // Now fund the contract
      console.log('Funding AIM tokens...');
      const fundTx = await stakingContract.fundAimTokens(amountInWei);
      await fundTx.wait();

      console.log('AIM tokens funded successfully!');

      // Refresh data
      await fetchBalances();
      await fetchAimFundingInfo();

      return true;
    } catch (error: any) {
      console.error('Error funding AIM tokens:', error);
      throw new Error(error.reason || error.message || 'Funding failed');
    } finally {
      setLoading(false);
    }
  };

  const ownerFundAimTokens = async (amount: string): Promise<boolean> => {
    if (!stakingContract || !aimContract || !account) {
      throw new Error('Contracts not initialized or wallet not connected');
    }

    if (!isOwner) {
      throw new Error('Only contract owner can use owner funding function');
    }

    try {
      setLoading(true);

      const amountInWei = ethers.parseEther(amount);

      // First, check if owner has enough AIM tokens
      const balance = await aimContract.balanceOf(account);
      if (balance < amountInWei) {
        throw new Error('Insufficient AIM balance');
      }

      // Check allowance
      const allowance = await aimContract.allowance(account, CONTRACTS.AIM_STAKING);

      // If allowance is insufficient, approve first
      if (allowance < amountInWei) {
        console.log('Approving AIM spending...');
        const approveTx = await aimContract.approve(CONTRACTS.AIM_STAKING, amountInWei);
        await approveTx.wait();
        console.log('AIM approved successfully');
      }

      // Now fund the contract as owner
      console.log('Owner funding AIM tokens...');
      const fundTx = await stakingContract.ownerFundAimTokens(amountInWei);
      await fundTx.wait();

      console.log('AIM tokens funded by owner successfully!');

      // Refresh data
      await fetchBalances();
      await fetchAimFundingInfo();

      return true;
    } catch (error: any) {
      console.error('Error owner funding AIM tokens:', error);
      throw new Error(error.reason || error.message || 'Owner funding failed');
    } finally {
      setLoading(false);
    }
  };

  const withdrawAimTokens = async (amount: string): Promise<boolean> => {
    if (!stakingContract || !account) {
      throw new Error('Contract not initialized or wallet not connected');
    }

    if (!isOwner) {
      throw new Error('Only contract owner can withdraw AIM tokens');
    }

    try {
      setLoading(true);

      const amountInWei = ethers.parseEther(amount);

      console.log('Withdrawing AIM tokens...');
      const withdrawTx = await stakingContract.withdrawAIM(amountInWei);
      await withdrawTx.wait();

      console.log('AIM tokens withdrawn successfully!');

      // Refresh data
      await fetchBalances();
      await fetchAimFundingInfo();

      return true;
    } catch (error: any) {
      console.error('Error withdrawing AIM tokens:', error);
      throw new Error(error.reason || error.message || 'Withdrawal failed');
    } finally {
      setLoading(false);
    }
  };

  const switchToBSC = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: BSC_CHAIN_ID }],
        });
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [
                {
                  chainId: BSC_CHAIN_ID,
                  chainName: 'BNB Smart Chain',
                  nativeCurrency: {
                    name: 'BNB',
                    symbol: 'BNB',
                    decimals: 18,
                  },
                  rpcUrls: [BSC_RPC_URL],
                  blockExplorerUrls: ['https://bscscan.com/'],
                },
              ],
            });
          } catch (addError) {
            console.error('Error adding BSC network:', addError);
          }
        }
      }
    }
  };

  const connectWallet = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        setLoading(true);
        
        // Request account access
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        
        // Switch to BSC if not already on it
        await switchToBSC();
        
        const provider = new ethers.BrowserProvider(window.ethereum);
        const signer = await provider.getSigner();
        const address = await signer.getAddress();
        
        setProvider(provider);
        setSigner(signer);
        setAccount(address);
        setIsConnected(true);
        
        console.log('Connected to wallet:', address);
      } catch (error) {
        console.error('Error connecting wallet:', error);
        alert('Failed to connect wallet. Please try again.');
      } finally {
        setLoading(false);
      }
    } else {
      alert('Please install MetaMask or another Web3 wallet!');
    }
  };

  const disconnectWallet = () => {
    setAccount(null);
    setProvider(null);
    setSigner(null);
    setIsConnected(false);
    setIsOwner(false);
    setAimContract(null);
    setUsdtContract(null);
    setStakingContract(null);
    setUserStakeInfo(null);
    setReferralInfo(null);
    setAimBalance('0');
    setUsdtBalance('0');
    setBnbBalance('0');
    setTransactionHistory([]);
    setAimFundingInfo({
      contractBalance: '0',
      totalFunded: '0',
      totalDistributed: '0',
      availableForRewards: '0',
    });
  };

  const fetchBalances = async () => {
    if (!account || !provider) {
      console.log('🔍 fetchBalances: No account or provider available');
      return;
    }
    
    console.log('🔍 fetchBalances: Starting balance fetch for account:', account);
    
    try {
      // Fetch BNB balance
      console.log('🔍 fetchBalances: Fetching BNB balance...');
      const bnbBal = await provider.getBalance(account);
      console.log('🔍 fetchBalances: Raw BNB balance (BigInt):', bnbBal.toString());
      
      const formattedBnbBalance = ethers.formatEther(bnbBal);
      console.log('🔍 fetchBalances: Formatted BNB balance:', formattedBnbBalance);
      setBnbBalance(formattedBnbBalance);
      
      if (aimContract && usdtContract) {
        console.log('🔍 fetchBalances: Contracts available, fetching token balances...');
        
        // Fetch AIM balance
        console.log('🔍 fetchBalances: Fetching AIM balance...');
        const aimBal = await aimContract.balanceOf(account);
        console.log('🔍 fetchBalances: Raw AIM balance (BigInt):', aimBal.toString());
        
        const formattedAimBalance = ethers.formatEther(aimBal);
        console.log('🔍 fetchBalances: Formatted AIM balance:', formattedAimBalance);
        setAimBalance(formattedAimBalance);
        
        // Fetch USDT balance (18 decimals on BSC)
        console.log('🔍 fetchBalances: Fetching USDT balance...');
        const usdtBal = await usdtContract.balanceOf(account);
        console.log('🔍 fetchBalances: Raw USDT balance (BigInt):', usdtBal.toString());
        
        const formattedUsdtBalance = ethers.formatEther(usdtBal);
        console.log('🔍 fetchBalances: Formatted USDT balance:', formattedUsdtBalance);
        setUsdtBalance(formattedUsdtBalance);
      } else {
        console.log('🔍 fetchBalances: Token contracts not available yet');
        console.log('🔍 fetchBalances: aimContract:', aimContract ? 'Available' : 'Not available');
        console.log('🔍 fetchBalances: usdtContract:', usdtContract ? 'Available' : 'Not available');
      }
      
      console.log('🔍 fetchBalances: Balance fetch completed successfully');
    } catch (error) {
      console.error('🔍 fetchBalances: Error fetching balances:', error);
      console.error('🔍 fetchBalances: Error details:', {
        message: error.message,
        code: error.code,
        data: error.data
      });
    }
  };

  const fetchUserData = async () => {
    if (!account || !stakingContract) return;
    
    try {
      // Fetch user stake info
      const stakeInfo = await stakingContract.getUserStakeInfo(account);
      setUserStakeInfo({
        planId: Number(stakeInfo.planId),
        amount: ethers.formatEther(stakeInfo.amount),
        startTime: Number(stakeInfo.startTime),
        lastClaimTime: Number(stakeInfo.lastClaimTime),
        dailyReward: ethers.formatEther(stakeInfo.dailyReward), // Keep as USDT value
        active: stakeInfo.active,
        holdBonus: stakeInfo.holdBonus,
        claimableRewards: convertUsdtToAim(ethers.formatEther(stakeInfo.claimableRewards)), // Convert to AIM
        remainingTime: Number(stakeInfo.remainingTime),
      });
      
      // Fetch referral info
      const refInfo = await stakingContract.getReferralInfo(account);
      setReferralInfo({
        referrer: refInfo.referrer,
        totalReferrals: Number(refInfo.totalReferrals),
        totalEarnings: convertUsdtToAim(ethers.formatEther(refInfo.totalEarnings)), // Convert to AIM
      });
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const fetchGlobalData = async () => {
    if (!stakingContract) return;
    
    try {
      // Fetch global stats
      const totalStakedAmount = await stakingContract.totalStaked();
      const totalUsersCount = await stakingContract.totalUsers();
      const totalPlansCount = await stakingContract.totalPlans();
      
      setTotalStaked(ethers.formatEther(totalStakedAmount));
      setTotalUsers(Number(totalUsersCount));
      
      // Fetch staking plans
      const plans: StakingPlan[] = [];
      for (let i = 0; i < Number(totalPlansCount); i++) {
        const plan = await stakingContract.getStakingPlan(i);
        plans.push({
          duration: Number(plan.duration),
          totalReturn: Number(plan.totalReturn),
          active: plan.active,
          amounts: plan.amounts.map((amount: any) => ethers.formatEther(amount)),
          dailyRewards: plan.dailyRewards.map((reward: any) => ethers.formatEther(reward)), // Keep as USDT values
        });
      }
      setStakingPlans(plans);
      
      // Debug log for staking plans
      console.log('🔍 fetchGlobalData: Staking plans loaded:', plans);
      plans.forEach((plan, index) => {
        console.log(`🔍 Plan ${index + 1} amounts:`, plan.amounts);
        console.log(`🔍 Plan ${index + 1} daily rewards (USDT):`, plan.dailyRewards);
      });
    } catch (error) {
      console.error('Error fetching global data:', error);
    }
  };

  const getReferralLevelInfo = async (level: number): Promise<{ referrals: number; earnings: string }> => {
    if (!account || !stakingContract) {
      return { referrals: 0, earnings: '0' };
    }
    
    try {
      const levelInfo = await stakingContract.getReferralLevelInfo(account, level);
      return {
        referrals: Number(levelInfo.referrals),
        earnings: convertUsdtToAim(ethers.formatEther(levelInfo.earnings)), // Convert to AIM
      };
    } catch (error) {
      console.error('Error fetching referral level info:', error);
      return { referrals: 0, earnings: '0' };
    }
  };

  const stakeUSDT = async (planId: number, amount: string, referrer: string = ethers.ZeroAddress): Promise<boolean> => {
    if (!stakingContract || !usdtContract || !account) {
      throw new Error('Contracts not initialized or wallet not connected');
    }
    
    try {
      setLoading(true);
      
      // Debug logs for amount conversion
      console.log('🔍 stakeUSDT: Input amount string:', amount);
      console.log('🔍 stakeUSDT: Input amount type:', typeof amount);
      
      const amountInWei = ethers.parseEther(amount);
      console.log('🔍 stakeUSDT: Amount in Wei (BigInt):', amountInWei.toString());
      console.log('🔍 stakeUSDT: Amount in Wei (hex):', amountInWei.toString(16));
      
      // Verify the conversion back
      const verifyAmount = ethers.formatEther(amountInWei);
      console.log('🔍 stakeUSDT: Verification - converted back to string:', verifyAmount);
      
      // First, check if user has enough USDT
      const balance = await usdtContract.balanceOf(account);
      console.log('🔍 stakeUSDT: User USDT balance (BigInt):', balance.toString());
      console.log('🔍 stakeUSDT: User USDT balance (formatted):', ethers.formatEther(balance));
      
      if (balance < amountInWei) {
        throw new Error('Insufficient USDT balance');
      }
      
      // Check allowance
      const allowance = await usdtContract.allowance(account, CONTRACTS.AIM_STAKING);
      console.log('🔍 stakeUSDT: Current allowance (BigInt):', allowance.toString());
      console.log('🔍 stakeUSDT: Current allowance (formatted):', ethers.formatEther(allowance));
      
      // If allowance is insufficient, approve first
      if (allowance < amountInWei) {
        console.log('🔍 stakeUSDT: Approving USDT spending...');
        console.log('🔍 stakeUSDT: Approval amount (BigInt):', amountInWei.toString());
        
        const approveTx = await usdtContract.approve(CONTRACTS.AIM_STAKING, amountInWei);
        console.log('🔍 stakeUSDT: Approval transaction hash:', approveTx.hash);
        await approveTx.wait();
        console.log('🔍 stakeUSDT: USDT approved successfully');
      }
      
      // Now stake
      console.log('🔍 stakeUSDT: Staking USDT...');
      console.log('🔍 stakeUSDT: Plan ID:', planId);
      console.log('🔍 stakeUSDT: Amount to stake (BigInt):', amountInWei.toString());
      console.log('🔍 stakeUSDT: Referrer address:', referrer);
      
      const stakeTx = await stakingContract.stake(planId, amountInWei, referrer);
      console.log('🔍 stakeUSDT: Stake transaction hash:', stakeTx.hash);
      await stakeTx.wait();
      
      console.log('🔍 stakeUSDT: Staking successful!');
      
      // Refresh user data
      await fetchUserData();
      await fetchBalances();
      await fetchGlobalData();
      await fetchAimFundingInfo();
      await fetchTransactionHistory(); // Refresh transaction history
      
      return true;
    } catch (error: any) {
      console.error('🔍 stakeUSDT: Error staking USDT:', error);
      console.error('🔍 stakeUSDT: Error details:', {
        message: error.message,
        code: error.code,
        data: error.data,
        reason: error.reason
      });
      throw new Error(error.reason || error.message || 'Staking failed');
    } finally {
      setLoading(false);
    }
  };

  const claimRewards = async (): Promise<boolean> => {
    if (!stakingContract || !account) {
      throw new Error('Contract not initialized or wallet not connected');
    }
    
    try {
      setLoading(true);
      
      console.log('Claiming rewards...');
      const claimTx = await stakingContract.claimRewards();
      await claimTx.wait();
      
      console.log('Rewards claimed successfully!');
      
      // Refresh user data
      await fetchUserData();
      await fetchBalances();
      await fetchAimFundingInfo();
      await fetchTransactionHistory(); // Refresh transaction history
      
      return true;
    } catch (error: any) {
      console.error('Error claiming rewards:', error);
      throw new Error(error.reason || error.message || 'Claiming failed');
    } finally {
      setLoading(false);
    }
  };

  const value: Web3ContextType = {
    account,
    provider,
    signer,
    aimPrice,
    priceInfo,
    aimFundingInfo,
    isConnected,
    loading,
    isOwner,
    
    // Contract instances
    aimContract,
    usdtContract,
    stakingContract,
    
    // Balances
    aimBalance,
    usdtBalance,
    bnbBalance,
    
    // Staking data
    userStakeInfo,
    referralInfo,
    totalStaked,
    totalUsers,
    stakingPlans,
    
    // Transaction history
    transactionHistory,
    
    // Functions
    connectWallet,
    disconnectWallet,
    switchToBSC,
    
    // Contract functions
    stakeUSDT,
    claimRewards,
    fundAimTokens,
    ownerFundAimTokens,
    updateContractAimPrice,
    togglePancakeSwapPrice,
    withdrawAimTokens,
    
    // Data fetching functions
    fetchUserData,
    fetchGlobalData,
    fetchBalances,
    fetchAimFundingInfo,
    fetchTransactionHistory,
    getReferralLevelInfo,
    
    // Utility functions
    convertUsdtToAim,
    convertAimToUsdt,
  };

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
};

export const useWeb3 = () => {
  const context = useContext(Web3Context);
  if (context === undefined) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
};