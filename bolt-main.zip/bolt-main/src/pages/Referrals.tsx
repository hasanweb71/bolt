import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  Grid,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  TextField,
  InputAdornment,
  IconButton,
  CircularProgress,
  Divider,
  Avatar,
} from '@mui/material';
import { 
  ContentCopy, 
  Share, 
  TrendingUp, 
  Group, 
  AccountBalance, 
  Person,
  EmojiEvents,
  Visibility
} from '@mui/icons-material';
import { useWeb3 } from '../contexts/Web3Context';

const Referrals: React.FC = () => {
  const { account, isConnected, referralInfo, getReferralLevelInfo } = useWeb3();
  const [referralLevels, setReferralLevels] = useState<Array<{ referrals: number; earnings: string }>>([]);
  const [loading, setLoading] = useState(false);
  
  const referralLink = `${window.location.origin}?ref=${account || 'connect-wallet'}`;

  const commissionStructure = [
    { level: 1, commission: '3%', description: 'Direct referrals' },
    { level: 2, commission: '2%', description: 'Second level' },
    { level: 3, commission: '1%', description: 'Third level' },
    { level: 4, commission: '1%', description: 'Fourth level' },
    { level: 5, commission: '1%', description: 'Fifth level' },
    { level: 6, commission: '3%', description: 'Sixth level' },
    { level: 7, commission: '2%', description: 'Seventh level' },
    { level: 8, commission: '1%', description: 'Eighth level' },
    { level: 9, commission: '1%', description: 'Ninth level' },
    { level: 10, commission: '1%', description: 'Tenth level' },
  ];

  // Fetch referral level data
  useEffect(() => {
    const fetchReferralLevels = async () => {
      if (!isConnected || !account) return;
      
      setLoading(true);
      try {
        const levels = [];
        for (let i = 0; i < 10; i++) {
          const levelData = await getReferralLevelInfo(i);
          levels.push(levelData);
        }
        setReferralLevels(levels);
      } catch (error) {
        console.error('Error fetching referral levels:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReferralLevels();
  }, [isConnected, account, getReferralLevelInfo]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    alert('Referral link copied to clipboard!');
  };

  const handleShareLink = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join AIM Finance',
          text: 'Start earning with AIM Finance DeFi staking platform!',
          url: referralLink,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      handleCopyLink();
    }
  };

  const getTotalNetworkReferrals = () => {
    return referralLevels.reduce((total, level) => total + level.referrals, 0);
  };

  const truncateAddress = (address: string) => {
    if (!address || address === '0x0000000000000000000000000000000000000000') return 'None';
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <Container maxWidth="sm" sx={{ py: 2 }}>
      {/* Professional Referral Status */}
      <Card 
        sx={{ 
          mb: 3, 
          background: 'linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 50%, #1a1a1a 100%)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: 3,
          overflow: 'hidden',
          position: 'relative',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '4px',
            background: 'linear-gradient(90deg, #b704db 0%, #007BFF 100%)',
          }
        }}
      >
        <CardContent sx={{ p: 3 }}>
          {/* Header */}
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Avatar
              sx={{
                width: 56,
                height: 56,
                mx: 'auto',
                mb: 2,
                background: 'linear-gradient(135deg, #b704db 0%, #007BFF 100%)',
              }}
            >
              <Group sx={{ fontSize: 28 }} />
            </Avatar>
            <Typography 
              variant="h5" 
              sx={{ 
                fontWeight: 700,
                mb: 1,
                background: 'linear-gradient(135deg, #b704db 0%, #007BFF 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Referral Dashboard
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ opacity: 0.8 }}>
              Track your network growth and earnings
            </Typography>
          </Box>

          {isConnected ? (
            <>
              {/* Main Stats Grid */}
              <Grid container spacing={3} sx={{ mb: 3 }}>
                <Grid item xs={6}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <Person sx={{ color: 'primary.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Direct
                      </Typography>
                    </Box>
                    <Typography 
                      variant="h4" 
                      sx={{ 
                        fontWeight: 700,
                        color: 'primary.main',
                        lineHeight: 1,
                      }}
                    >
                      {referralInfo?.totalReferrals || 0}
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <Group sx={{ color: 'secondary.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Network
                      </Typography>
                    </Box>
                    <Typography 
                      variant="h4" 
                      sx={{ 
                        fontWeight: 700,
                        color: 'secondary.main',
                        lineHeight: 1,
                      }}
                    >
                      {loading ? <CircularProgress size={24} color="secondary" /> : getTotalNetworkReferrals()}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>

              <Divider sx={{ my: 3, borderColor: 'rgba(255, 255, 255, 0.1)' }} />

              {/* Earnings and Referrer Info */}
              <Grid container spacing={3}>
                <Grid item xs={6}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <TrendingUp sx={{ color: 'success.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Total Earnings
                      </Typography>
                    </Box>
                    <Typography 
                      variant="h5" 
                      sx={{ 
                        fontWeight: 700,
                        color: 'success.main',
                        lineHeight: 1,
                      }}
                    >
                      {referralInfo?.totalEarnings ? parseFloat(referralInfo.totalEarnings).toFixed(6) : '0.000000'} AIM
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <Visibility sx={{ color: 'info.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Referred By
                      </Typography>
                    </Box>
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        fontWeight: 600,
                        color: referralInfo?.referrer && referralInfo.referrer !== '0x0000000000000000000000000000000000000000' 
                          ? 'info.main' 
                          : 'text.secondary',
                        fontFamily: 'monospace',
                        fontSize: '0.9rem',
                      }}
                    >
                      {truncateAddress(referralInfo?.referrer || '')}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </>
          ) : (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <AccountBalance sx={{ fontSize: 48, color: 'text.secondary', mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                Connect Your Wallet
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ opacity: 0.7 }}>
                View your referral dashboard and earnings
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Referral Link */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            Your Referral Link
          </Typography>
          <TextField
            fullWidth
            value={referralLink}
            InputProps={{
              readOnly: true,
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={handleCopyLink} size="small">
                    <ContentCopy />
                  </IconButton>
                  <IconButton onClick={handleShareLink} size="small">
                    <Share />
                  </IconButton>
                </InputAdornment>
              ),
            }}
            sx={{ mb: 2 }}
          />
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleCopyLink}
              startIcon={<ContentCopy />}
              fullWidth
            >
              Copy Link
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleShareLink}
              startIcon={<Share />}
              fullWidth
            >
              Share
            </Button>
          </Box>
        </CardContent>
      </Card>

      {/* Commission Structure */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            Referral Commission Structure
          </Typography>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Level</TableCell>
                  <TableCell align="center">Commission</TableCell>
                  <TableCell align="right">Your Network</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {commissionStructure.map((row, index) => (
                  <TableRow key={row.level}>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                          Level {row.level}
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell align="center">
                      <Chip
                        label={row.commission}
                        color={row.level === 1 || row.level === 6 ? 'primary' : 'secondary'}
                        size="small"
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body2" color="success.main" sx={{ fontWeight: 'bold' }}>
                        {loading ? (
                          <CircularProgress size={16} />
                        ) : (
                          referralLevels[index]?.referrals || 0
                        )}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Level Earnings Breakdown */}
      {isConnected && !loading && referralLevels.some(level => level.referrals > 0) && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Level Earnings Breakdown
            </Typography>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Level</TableCell>
                    <TableCell align="center">Referrals</TableCell>
                    <TableCell align="right">Earnings (AIM)</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {referralLevels.map((level, index) => {
                    if (level.referrals === 0) return null;
                    return (
                      <TableRow key={index}>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                            Level {index + 1}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Typography variant="body2">
                            {level.referrals}
                          </Typography>
                        </TableCell>
                        <TableCell align="right">
                          <Typography variant="body2" color="success.main" sx={{ fontWeight: 'bold' }}>
                            {parseFloat(level.earnings).toFixed(6)} AIM
                          </Typography>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      {/* How It Works */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            How Referrals Work
          </Typography>
          <Box sx={{ pl: 2 }}>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Share your referral link with friends and family
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • When they stake USDT using your link, you earn AIM tokens instantly
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Earn from 10 levels deep in your referral network
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Higher commissions at levels 1 and 6 (3% each)
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • All referral rewards are paid in AIM tokens automatically
            </Typography>
            <Typography variant="body2">
              • No claiming required - rewards are instant!
            </Typography>
          </Box>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Referrals;