import React from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  Grid,
  IconButton,
  Chip,
} from '@mui/material';
import { Telegram, Twitter } from '@mui/icons-material';
import { useWeb3 } from '../contexts/Web3Context';

const Home: React.FC = () => {
  const { totalStaked, totalUsers } = useWeb3();

  // Format numbers for display
  const formatNumber = (num: string | number) => {
    const numValue = typeof num === 'string' ? parseFloat(num) : num;
    if (numValue >= 1000000) {
      return (numValue / 1000000).toFixed(1) + 'M';
    } else if (numValue >= 1000) {
      return (numValue / 1000).toFixed(1) + 'K';
    }
    return numValue.toLocaleString();
  };

  return (
    <Container maxWidth="sm" sx={{ py: 2 }}>
      {/* Main Banner */}
      <Card
        sx={{
          mb: 3,
          background: 'linear-gradient(135deg, #b704db 0%, #007BFF 100%)',
          minHeight: 180,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: 3,
          position: 'relative',
          overflow: 'hidden',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.1) 0%, transparent 50%)',
            pointerEvents: 'none',
          },
        }}
      >
        <CardContent sx={{ textAlign: 'center', width: '100%', position: 'relative', zIndex: 1 }}>
          <Typography 
            variant="h4" 
            sx={{ 
              fontWeight: 'bold', 
              mb: 1,
              color: 'white',
              textShadow: '0 2px 4px rgba(0,0,0,0.3)',
            }}
          >
            AIM FINANCE
          </Typography>
          <Typography 
            variant="body1" 
            sx={{ 
              opacity: 0.95,
              color: 'white',
              mb: 2,
              fontWeight: 500,
            }}
          >
            Stake USDT • Earn AIM • Build Your Network
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1, flexWrap: 'wrap' }}>
            <Chip
              label="10-Level Referral"
              sx={{
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                color: 'white',
                fontWeight: 'bold',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
              }}
            />
            <Chip
              label="Daily Rewards"
              sx={{
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                color: 'white',
                fontWeight: 'bold',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
              }}
            />
          </Box>
        </CardContent>
      </Card>

      {/* Total Info */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6}>
          <Card sx={{ background: 'linear-gradient(135deg, #1a1a1a, #2a2a2a)' }}>
            <CardContent sx={{ textAlign: 'center', py: 2 }}>
              <Typography variant="h6" color="secondary" sx={{ fontWeight: 'bold' }}>
                ${formatNumber(totalStaked)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Total Staked
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={6}>
          <Card sx={{ background: 'linear-gradient(135deg, #1a1a1a, #2a2a2a)' }}>
            <CardContent sx={{ textAlign: 'center', py: 2 }}>
              <Typography variant="h6" color="primary" sx={{ fontWeight: 'bold' }}>
                {formatNumber(totalUsers)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Total Users
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* DexScreener Trading Chart */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            AIM/BNB Trading Chart
          </Typography>
          <Box
            sx={{
              width: '100%',
              borderRadius: 2,
              overflow: 'hidden',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              position: 'relative',
              paddingBottom: '162.5%', // Increased from 125% by 30%
              '@media (min-width: 1400px)': {
                paddingBottom: '84.5%', // Increased from 65% by 30%
              },
            }}
          >
            <Box
              component="iframe"
              src="https://dexscreener.com/bsc/0xC0d1E8A5371772B27b52EA7eF0a57EF9A4115A30?embed=1&loadChartSettings=0&chartLeftToolbar=0&chartDefaultOnMobile=1&chartTheme=dark&theme=dark&chartStyle=0&chartType=usd&interval=15"
              sx={{
                position: 'absolute',
                width: '100%',
                height: '100%',
                top: 0,
                left: 0,
                border: 0,
              }}
            />
          </Box>
        </CardContent>
      </Card>

      {/* Partners Logo Slider */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, textAlign: 'center', fontWeight: 'bold' }}>
            Our Partners
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, flexWrap: 'wrap' }}>
            {['PancakeSwap', 'BNB Chain', 'CoinGecko', 'DEX Screener'].map((partner) => (
              <Chip
                key={partner}
                label={partner}
                variant="outlined"
                sx={{ borderColor: 'primary.main', color: 'primary.main' }}
              />
            ))}
          </Box>
        </CardContent>
      </Card>

      {/* Social Media Links */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, textAlign: 'center', fontWeight: 'bold' }}>
            Join Our Community
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
            <IconButton
              color="primary"
              href="https://t.me/aimfinance"
              target="_blank"
              sx={{
                background: 'linear-gradient(45deg, #0088cc, #0088cc)',
                color: 'white',
                '&:hover': {
                  background: 'linear-gradient(45deg, #006699, #006699)',
                },
              }}
            >
              <Telegram />
            </IconButton>
            <IconButton
              color="primary"
              href="https://twitter.com/aimfinance"
              target="_blank"
              sx={{
                background: 'linear-gradient(45deg, #1da1f2, #1da1f2)',
                color: 'white',
                '&:hover': {
                  background: 'linear-gradient(45deg, #0d8bd9, #0d8bd9)',
                },
              }}
            >
              <Twitter />
            </IconButton>
          </Box>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Home;