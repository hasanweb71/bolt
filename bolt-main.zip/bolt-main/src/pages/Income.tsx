import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  Grid,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  LinearProgress,
  CircularProgress,
  Link,
} from '@mui/material';
import { TrendingUp, Group, AccountBalance, Schedule, OpenInNew } from '@mui/icons-material';
import { useWeb3 } from '../contexts/Web3Context';

const Income: React.FC = () => {
  const { 
    isConnected, 
    userStakeInfo, 
    referralInfo, 
    stakingPlans,
    transactionHistory,
    getReferralLevelInfo 
  } = useWeb3();
  
  const [referralLevels, setReferralLevels] = useState<Array<{ referrals: number; earnings: string }>>([]);
  const [loading, setLoading] = useState(false);

  // Fetch referral level data
  useEffect(() => {
    const fetchReferralLevels = async () => {
      if (!isConnected) return;
      
      setLoading(true);
      try {
        const levels = [];
        for (let i = 0; i < 10; i++) {
          const levelData = await getReferralLevelInfo(i);
          levels.push(levelData);
        }
        setReferralLevels(levels);
      } catch (error) {
        console.error('Error fetching referral levels:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReferralLevels();
  }, [isConnected, getReferralLevelInfo]);

  // Calculate derived data
  const getTotalStakingEarnings = () => {
    if (!userStakeInfo?.active) return 0;
    
    const plan = stakingPlans[userStakeInfo.planId];
    if (!plan) return 0;
    
    const daysPassed = Math.floor((Date.now() / 1000 - userStakeInfo.startTime) / (24 * 60 * 60));
    const totalDays = Math.min(daysPassed, plan.duration);
    
    return totalDays * parseFloat(userStakeInfo.dailyReward);
  };

  const getTotalReferralEarnings = () => {
    return parseFloat(referralInfo?.totalEarnings || '0');
  };

  const getTotalNetworkReferrals = () => {
    return referralLevels.reduce((total, level) => total + level.referrals, 0);
  };

  const getStakeProgress = () => {
    if (!userStakeInfo?.active) return 0;
    
    const plan = stakingPlans[userStakeInfo.planId];
    if (!plan) return 0;
    
    const daysPassed = Math.floor((Date.now() / 1000 - userStakeInfo.startTime) / (24 * 60 * 60));
    return Math.min((daysPassed / plan.duration) * 100, 100);
  };

  const formatTimeRemaining = (seconds: number) => {
    if (seconds <= 0) return 'Completed';
    
    const days = Math.floor(seconds / (24 * 60 * 60));
    const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
    
    if (days > 0) return `${days}d ${hours}h`;
    return `${hours}h`;
  };

  const getBSCScanLink = (txHash: string) => {
    return `https://bscscan.com/tx/${txHash}`;
  };

  return (
    <Container maxWidth="sm" sx={{ py: 2 }}>
      {/* Total Earnings Overview */}
      <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #1a1a1a, #2a2a2a)' }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', textAlign: 'center' }}>
            Total Income Overview
          </Typography>
          {isConnected ? (
            <>
              <Box sx={{ textAlign: 'center', mb: 3 }}>
                <Typography variant="h4" color="success.main" sx={{ fontWeight: 'bold' }}>
                  {(getTotalStakingEarnings() + getTotalReferralEarnings()).toFixed(6)} AIM
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Lifetime Earnings
                </Typography>
              </Box>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h6" color="primary" sx={{ fontWeight: 'bold' }}>
                      {getTotalStakingEarnings().toFixed(6)} AIM
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Staking Earnings
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="h6" color="secondary" sx={{ fontWeight: 'bold' }}>
                      {getTotalReferralEarnings().toFixed(6)} AIM
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Referral Earnings
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </>
          ) : (
            <Box sx={{ textAlign: 'center', py: 2 }}>
              <Typography variant="body1" color="text.secondary">
                Connect your wallet to view income data
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Current Rewards */}
      {isConnected && userStakeInfo?.active && (
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={6}>
            <Card sx={{ background: 'linear-gradient(135deg, #1a1a1a, #2a2a2a)' }}>
              <CardContent sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="h6" color="success.main" sx={{ fontWeight: 'bold' }}>
                  {parseFloat(userStakeInfo.claimableRewards).toFixed(6)} AIM
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Claimable Now
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card sx={{ background: 'linear-gradient(135deg, #1a1a1a, #2a2a2a)' }}>
              <CardContent sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="h6" color="primary" sx={{ fontWeight: 'bold' }}>
                  {parseFloat(userStakeInfo.dailyReward).toFixed(6)} AIM
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Daily Reward
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Stats Cards */}
      {isConnected && (
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={6}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <AccountBalance color="primary" sx={{ fontSize: 40, mb: 1 }} />
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  {userStakeInfo?.active ? 1 : 0}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Active Stakes
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Group color="secondary" sx={{ fontSize: 40, mb: 1 }} />
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  {loading ? <CircularProgress size={20} /> : (referralInfo?.totalReferrals || 0)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Direct Referrals
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Current Stake Info */}
      {isConnected && userStakeInfo?.active && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Current Stake
            </Typography>
            <Box sx={{ mb: 2, p: 2, border: '1px solid rgba(255, 255, 255, 0.1)', borderRadius: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                  Plan {userStakeInfo.planId + 1}
                </Typography>
                <Chip
                  label={userStakeInfo.remainingTime > 0 ? 'Active' : 'Completed'}
                  color={userStakeInfo.remainingTime > 0 ? 'primary' : 'success'}
                  size="small"
                />
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">
                  Staked: ${parseFloat(userStakeInfo.amount).toFixed(2)} USDT
                </Typography>
                <Typography variant="body2" color="success.main">
                  Earned: {getTotalStakingEarnings().toFixed(6)} AIM
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">
                  Time Remaining: {formatTimeRemaining(userStakeInfo.remainingTime)}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Hold Bonus: {userStakeInfo.holdBonus ? 'Active' : 'Used'}
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <LinearProgress
                  variant="determinate"
                  value={getStakeProgress()}
                  sx={{ flexGrow: 1, height: 8, borderRadius: 4 }}
                />
                <Typography variant="body2" color="text.secondary">
                  {getStakeProgress().toFixed(0)}%
                </Typography>
              </Box>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Referral Network Summary */}
      {isConnected && !loading && referralLevels.some(level => level.referrals > 0) && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Referral Network Summary
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="h6" color="primary" sx={{ fontWeight: 'bold' }}>
                    {referralInfo?.totalReferrals || 0}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Direct
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="h6" color="secondary" sx={{ fontWeight: 'bold' }}>
                    {getTotalNetworkReferrals()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Network
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="h6" color="success.main" sx={{ fontWeight: 'bold' }}>
                    {getTotalReferralEarnings().toFixed(6)} AIM
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Earned
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      )}

      {/* Recent Transactions */}
      {isConnected && transactionHistory.length > 0 && (
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Recent Activity
            </Typography>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Type</TableCell>
                    <TableCell align="right">Amount</TableCell>
                    <TableCell align="right">Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {transactionHistory.slice(0, 10).map((transaction, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {transaction.type.includes('Staking') ? (
                            <TrendingUp fontSize="small" color="primary" />
                          ) : (
                            <Group fontSize="small" color="secondary" />
                          )}
                          <Box>
                            <Typography variant="body2">
                              {transaction.type}
                            </Typography>
                            {transaction.txHash && (
                              <Link
                                href={getBSCScanLink(transaction.txHash)}
                                target="_blank"
                                rel="noopener noreferrer"
                                sx={{ 
                                  display: 'flex', 
                                  alignItems: 'center', 
                                  gap: 0.5,
                                  fontSize: '0.7rem',
                                  color: 'text.secondary',
                                  textDecoration: 'none',
                                  '&:hover': {
                                    color: 'primary.main',
                                  }
                                }}
                              >
                                View TX <OpenInNew sx={{ fontSize: 10 }} />
                              </Link>
                            )}
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" color="success.main" sx={{ fontWeight: 'bold' }}>
                          {transaction.type === 'Staking' 
                            ? `$${transaction.amount.toFixed(2)} USDT`
                            : `${transaction.amount.toFixed(6)} AIM`
                          }
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {transaction.date}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Chip
                          label={transaction.status}
                          color={transaction.status === 'Completed' ? 'success' : 'primary'}
                          size="small"
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            {transactionHistory.length === 0 && (
              <Box sx={{ textAlign: 'center', py: 2 }}>
                <Typography variant="body2" color="text.secondary">
                  No recent transactions found
                </Typography>
              </Box>
            )}
          </CardContent>
        </Card>
      )}

      {/* No transactions message for connected users */}
      {isConnected && transactionHistory.length === 0 && (
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Recent Activity
            </Typography>
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Schedule sx={{ fontSize: 48, color: 'text.secondary', mb: 2, opacity: 0.5 }} />
              <Typography variant="body1" color="text.secondary" sx={{ mb: 1 }}>
                No Recent Activity
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ opacity: 0.7 }}>
                Your transaction history will appear here once you start staking or earning referral rewards
              </Typography>
            </Box>
          </CardContent>
        </Card>
      )}
    </Container>
  );
};

export default Income;