import React from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  Grid,
  Button,
  Chip,
} from '@mui/material';
import {
  SportsEsports,
  Casino,
  EmojiEvents,
  Schedule,
  Construction,
} from '@mui/icons-material';

const PlayToEarn: React.FC = () => {
  const upcomingFeatures = [
    {
      title: 'Crypto Games',
      description: 'Play exciting games and earn AIM tokens as rewards',
      icon: <SportsEsports sx={{ fontSize: 40 }} />,
      status: 'In Development',
      estimatedLaunch: 'Q2 2024',
    },
    {
      title: 'Smart Contract Lottery',
      description: 'Participate in transparent, blockchain-based lottery draws',
      icon: <Casino sx={{ fontSize: 40 }} />,
      status: 'Planned',
      estimatedLaunch: 'Q3 2024',
    },
    {
      title: 'Tournament System',
      description: 'Compete in tournaments with AIM token prizes',
      icon: <EmojiEvents sx={{ fontSize: 40 }} />,
      status: 'Concept',
      estimatedLaunch: 'Q4 2024',
    },
  ];

  const gameTypes = [
    'Strategy Games',
    'Puzzle Games',
    'Card Games',
    'Arcade Games',
    'Sports Betting',
    'Prediction Games',
  ];

  return (
    <Container maxWidth="sm" sx={{ py: 2 }}>
      {/* Coming Soon Header */}
      <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #b704db, #007BFF)' }}>
        <CardContent sx={{ textAlign: 'center' }}>
          <Construction sx={{ fontSize: 60, mb: 2 }} />
          <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 1 }}>
            Play2Earn Coming Soon!
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.9 }}>
            Get ready for exciting crypto games and lottery systems
          </Typography>
        </CardContent>
      </Card>

      {/* Upcoming Features */}
      <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
        Upcoming Features
      </Typography>
      {upcomingFeatures.map((feature, index) => (
        <Card key={index} sx={{ mb: 2 }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
              <Box sx={{ color: 'primary.main' }}>
                {feature.icon}
              </Box>
              <Box sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                  <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                    {feature.title}
                  </Typography>
                  <Chip
                    label={feature.status}
                    color={feature.status === 'In Development' ? 'primary' : 'secondary'}
                    size="small"
                  />
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                  {feature.description}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Schedule fontSize="small" color="action" />
                  <Typography variant="body2" color="text.secondary">
                    Expected: {feature.estimatedLaunch}
                  </Typography>
                </Box>
              </Box>
            </Box>
          </CardContent>
        </Card>
      ))}

      {/* Game Types Preview */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            Planned Game Categories
          </Typography>
          <Grid container spacing={1}>
            {gameTypes.map((type, index) => (
              <Grid item xs={6} key={index}>
                <Chip
                  label={type}
                  variant="outlined"
                  sx={{
                    width: '100%',
                    borderColor: 'primary.main',
                    color: 'primary.main',
                  }}
                />
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      {/* How It Will Work */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            How Play2Earn Will Work
          </Typography>
          <Box sx={{ pl: 2 }}>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Play games using AIM tokens as entry fees
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Win AIM token rewards based on performance
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Participate in daily, weekly, and monthly tournaments
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Earn bonus rewards for consistent play
            </Typography>
            <Typography variant="body2" sx={{ mb: 1 }}>
              • Lottery system with guaranteed payouts
            </Typography>
            <Typography variant="body2">
              • Provably fair gaming using smart contracts
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Lottery Preview */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            Smart Contract Lottery
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <Casino color="secondary" sx={{ fontSize: 30 }} />
            <Box>
              <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                Transparent & Fair
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Blockchain-based random number generation
              </Typography>
            </Box>
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            • Multiple lottery pools with different entry fees
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            • Daily, weekly, and mega jackpot draws
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            • Automatic prize distribution via smart contract
          </Typography>
          <Typography variant="body2" color="text.secondary">
            • Verifiable results on blockchain
          </Typography>
        </CardContent>
      </Card>

      {/* Stay Updated */}
      <Card>
        <CardContent sx={{ textAlign: 'center' }}>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
            Stay Updated
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Follow our social media channels for the latest updates on Play2Earn features
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
            <Button
              variant="outlined"
              color="primary"
              href="https://t.me/aimfinance"
              target="_blank"
            >
              Telegram
            </Button>
            <Button
              variant="outlined"
              color="primary"
              href="https://twitter.com/aimfinance"
              target="_blank"
            >
              Twitter
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Container>
  );
};

export default PlayToEarn;