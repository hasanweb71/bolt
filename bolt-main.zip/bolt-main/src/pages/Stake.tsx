import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Card,
  CardContent,
  Box,
  Grid,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
  CircularProgress,
  Alert,
  Tooltip,
  Switch,
  FormControlLabel,
  TextField,
  InputAdornment,
  Avatar,
  Paper,
} from '@mui/material';
import { AccountBalance, TrendingUp, AccessTime, SwapHoriz, Warning, CheckCircle, Refresh, Settings, AccountBalanceWallet, Schedule, MonetizationOn } from '@mui/icons-material';
import { ethers } from 'ethers';
import { useWeb3 } from '../contexts/Web3Context';

const Stake: React.FC = () => {
  const { 
    account, 
    isConnected, 
    aimPrice, 
    priceInfo,
    aimFundingInfo,
    loading,
    isOwner,
    userStakeInfo,
    stakingPlans,
    usdtBalance,
    bnbBalance,
    aimBalance,
    stakeUSDT,
    claimRewards,
    fundAimTokens,
    ownerFundAimTokens,
    updateContractAimPrice,
    togglePancakeSwapPrice,
    withdrawAimTokens,
    fetchUserData,
    convertUsdtToAim
  } = useWeb3();
  
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const [selectedAmount, setSelectedAmount] = useState<string>('');
  const [confirmDialog, setConfirmDialog] = useState(false);
  const [claimDialog, setClaimDialog] = useState(false);
  const [fundDialog, setFundDialog] = useState(false);
  const [withdrawDialog, setWithdrawDialog] = useState(false);
  const [fundAmount, setFundAmount] = useState<string>('');
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');

  // Get referrer from URL if present
  const getReferrerFromURL = (): string => {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    return ref || ethers.ZeroAddress;
  };

  const formatTimeRemaining = (seconds: number) => {
    if (seconds <= 0) return 'Completed';
    
    const days = Math.floor(seconds / (24 * 60 * 60));
    const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
    const minutes = Math.floor((seconds % (60 * 60)) / 60);
    
    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const handleStake = () => {
    if (!isConnected) {
      setError('Please connect your wallet first!');
      return;
    }
    if (selectedPlan === null || !selectedAmount) {
      setError('Please select a plan and amount!');
      return;
    }
    
    // Check if user has sufficient USDT balance
    const amountNum = parseFloat(selectedAmount);
    const balanceNum = parseFloat(usdtBalance);
    
    console.log('🔍 handleStake: Selected amount (number):', amountNum);
    console.log('🔍 handleStake: USDT balance (number):', balanceNum);
    console.log('🔍 handleStake: Selected amount (string):', selectedAmount);
    console.log('🔍 handleStake: USDT balance (string):', usdtBalance);
    
    if (amountNum > balanceNum) {
      setError(`Insufficient USDT balance. You have ${balanceNum} USDT but need ${amountNum} USDT.`);
      return;
    }
    
    setError('');
    setConfirmDialog(true);
  };

  const handleConfirmStake = async () => {
    if (selectedPlan === null || !selectedAmount) return;
    
    try {
      setError('');
      const referrer = getReferrerFromURL();
      
      // Validate referrer address format
      let validReferrer = ethers.ZeroAddress;
      if (referrer && referrer !== ethers.ZeroAddress) {
        try {
          // Check if it's a valid address format
          validReferrer = ethers.getAddress(referrer);
        } catch (addressError) {
          console.warn('Invalid referrer address format, using zero address:', referrer);
          validReferrer = ethers.ZeroAddress;
        }
      }
      
      console.log('🔍 handleConfirmStake: Selected plan:', selectedPlan);
      console.log('🔍 handleConfirmStake: Selected amount:', selectedAmount);
      console.log('🔍 handleConfirmStake: Referrer:', validReferrer);
      
      await stakeUSDT(selectedPlan, selectedAmount, validReferrer);
      
      setSuccess('Staking successful! Your stake is now active.');
      setConfirmDialog(false);
      setSelectedPlan(null);
      setSelectedAmount('');
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (error: any) {
      console.error('🔍 handleConfirmStake: Staking error:', error);
      setError(error.message || 'Staking failed. Please try again.');
      setConfirmDialog(false);
    }
  };

  const handleClaim = () => {
    if (!isConnected) {
      setError('Please connect your wallet first!');
      return;
    }
    if (!userStakeInfo?.claimableRewards || parseFloat(userStakeInfo.claimableRewards) <= 0) {
      setError('No rewards available to claim!');
      return;
    }
    
    setError('');
    setClaimDialog(true);
  };

  const handleConfirmClaim = async () => {
    try {
      setError('');
      await claimRewards();
      
      setSuccess('Rewards claimed successfully!');
      setClaimDialog(false);
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (error: any) {
      setError(error.message || 'Claiming failed. Please try again.');
      setClaimDialog(false);
    }
  };

  const handleFundTokens = async () => {
    if (!fundAmount || parseFloat(fundAmount) <= 0) {
      setError('Please enter a valid amount to fund!');
      return;
    }
    
    try {
      setError('');
      if (isOwner) {
        await ownerFundAimTokens(fundAmount);
      } else {
        await fundAimTokens(fundAmount);
      }
      
      setSuccess(`Successfully funded ${fundAmount} AIM tokens to the contract!`);
      setFundDialog(false);
      setFundAmount('');
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (error: any) {
      setError(error.message || 'Funding failed. Please try again.');
    }
  };

  const handleWithdrawTokens = async () => {
    if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) {
      setError('Please enter a valid amount to withdraw!');
      return;
    }
    
    try {
      setError('');
      await withdrawAimTokens(withdrawAmount);
      
      setSuccess(`Successfully withdrew ${withdrawAmount} AIM tokens from the contract!`);
      setWithdrawDialog(false);
      setWithdrawAmount('');
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (error: any) {
      setError(error.message || 'Withdrawal failed. Please try again.');
    }
  };

  const handleUpdateContractPrice = async () => {
    try {
      setError('');
      await updateContractAimPrice();
      setSuccess('Contract price updated successfully!');
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (error: any) {
      setError(error.message || 'Price update failed. Please try again.');
    }
  };

  const handleTogglePancakeSwap = async () => {
    try {
      setError('');
      await togglePancakeSwapPrice(!priceInfo.usingPancakeSwap);
      setSuccess(`PancakeSwap pricing ${!priceInfo.usingPancakeSwap ? 'enabled' : 'disabled'} successfully!`);
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccess(''), 5000);
    } catch (error: any) {
      setError(error.message || 'Toggle failed. Please try again.');
    }
  };

  const getSelectedPlanData = () => {
    if (selectedPlan === null) return null;
    return stakingPlans[selectedPlan];
  };

  const getSelectedAmountReward = () => {
    const planData = getSelectedPlanData();
    if (!planData || !selectedAmount) return null;
    
    console.log('🔍 getSelectedAmountReward: Plan data amounts:', planData.amounts);
    console.log('🔍 getSelectedAmountReward: Selected amount:', selectedAmount);
    console.log('🔍 getSelectedAmountReward: Selected amount type:', typeof selectedAmount);
    
    const amountIndex = planData.amounts.findIndex(amount => {
      console.log('🔍 getSelectedAmountReward: Comparing', amount, 'with', selectedAmount);
      console.log('🔍 getSelectedAmountReward: Amount type:', typeof amount);
      return amount === selectedAmount;
    });
    
    console.log('🔍 getSelectedAmountReward: Amount index found:', amountIndex);
    
    if (amountIndex === -1) return null;
    
    const reward = planData.dailyRewards[amountIndex];
    console.log('🔍 getSelectedAmountReward: Daily reward (USDT):', reward);
    return reward;
  };

  const getPriceWarning = () => {
    if (!priceInfo.usingPancakeSwap) {
      return {
        severity: 'info' as const,
        message: 'PancakeSwap integration is disabled. Using fallback pricing.',
      };
    }
    
    if (!priceInfo.pairExists) {
      return {
        severity: 'warning' as const,
        message: 'No trading pair found on PancakeSwap. Using fallback price.',
      };
    }
    
    const priceDiff = Math.abs(priceInfo.realTimePrice - priceInfo.contractPrice);
    const diffPercentage = (priceDiff / priceInfo.realTimePrice) * 100;
    
    if (diffPercentage > 5) {
      return {
        severity: 'warning' as const,
        message: `Contract price ($${priceInfo.contractPrice.toFixed(6)}) differs from market price ($${priceInfo.realTimePrice.toFixed(6)}) by ${diffPercentage.toFixed(1)}%.`,
      };
    }
    
    return null;
  };

  const priceWarning = getPriceWarning();

  return (
    <Container maxWidth="sm" sx={{ py: 2 }}>
      {/* Error/Success Messages */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}
      {success && (
        <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess('')}>
          {success}
        </Alert>
      )}

      {/* Professional Staking Info Widget */}
      <Card 
        sx={{ 
          mb: 3, 
          background: 'linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 50%, #1a1a1a 100%)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: 3,
          overflow: 'hidden',
          position: 'relative',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '4px',
            background: 'linear-gradient(90deg, #b704db 0%, #007BFF 100%)',
          }
        }}
      >
        <CardContent sx={{ p: 3 }}>
          {/* Header */}
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Avatar
              sx={{
                width: 56,
                height: 56,
                mx: 'auto',
                mb: 2,
                background: 'linear-gradient(135deg, #b704db 0%, #007BFF 100%)',
              }}
            >
              <AccountBalance sx={{ fontSize: 28 }} />
            </Avatar>
            <Typography 
              variant="h5" 
              sx={{ 
                fontWeight: 700,
                mb: 1,
                background: 'linear-gradient(135deg, #b704db 0%, #007BFF 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              STAKE DASHBOARD
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ opacity: 0.8 }}>
              Monitor your staking performance and rewards
            </Typography>
          </Box>

          {isConnected ? (
            <>
              {/* Main Stats Grid */}
              <Grid container spacing={3} sx={{ mb: 3 }}>
                <Grid item xs={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      background: 'rgba(255, 255, 255, 0.02)',
                      border: '1px solid rgba(255, 255, 255, 0.05)',
                      borderRadius: 2,
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <MonetizationOn sx={{ color: 'secondary.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        AIM Balance
                      </Typography>
                    </Box>
                    <Typography 
                      variant="h4" 
                      sx={{ 
                        fontWeight: 700,
                        color: 'secondary.main',
                        lineHeight: 1,
                        fontFamily: 'monospace',
                      }}
                    >
                      {parseFloat(aimBalance).toFixed(2)}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ opacity: 0.7 }}>
                      AIM
                    </Typography>
                  </Paper>
                </Grid>
                <Grid item xs={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      background: 'rgba(255, 255, 255, 0.02)',
                      border: '1px solid rgba(255, 255, 255, 0.05)',
                      borderRadius: 2,
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <Schedule sx={{ color: 'primary.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Time Left
                      </Typography>
                    </Box>
                    <Typography 
                      variant="h5" 
                      sx={{ 
                        fontWeight: 700,
                        color: userStakeInfo?.remainingTime && userStakeInfo.remainingTime > 0 ? 'primary.main' : 'text.secondary',
                        lineHeight: 1,
                        fontFamily: 'monospace',
                        fontSize: '1.5rem',
                      }}
                    >
                      {userStakeInfo?.remainingTime ? formatTimeRemaining(userStakeInfo.remainingTime) : 'No Active Stake'}
                    </Typography>
                  </Paper>
                </Grid>
              </Grid>

              <Divider sx={{ my: 3, borderColor: 'rgba(255, 255, 255, 0.1)' }} />

              {/* Rewards and Status */}
              <Grid container spacing={3}>
                <Grid item xs={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      background: 'rgba(76, 175, 80, 0.1)',
                      border: '1px solid rgba(76, 175, 80, 0.2)',
                      borderRadius: 2,
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <TrendingUp sx={{ color: 'success.main', mr: 1, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Claimable
                      </Typography>
                    </Box>
                    <Typography 
                      variant="h5" 
                      sx={{ 
                        fontWeight: 700,
                        color: 'success.main',
                        lineHeight: 1,
                        fontFamily: 'monospace',
                      }}
                    >
                      {userStakeInfo?.claimableRewards ? parseFloat(userStakeInfo.claimableRewards).toFixed(6) : '0.000000'}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ opacity: 0.7 }}>
                      AIM Tokens
                    </Typography>
                  </Paper>
                </Grid>
                <Grid item xs={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      background: userStakeInfo?.active 
                        ? 'rgba(76, 175, 80, 0.1)' 
                        : 'rgba(158, 158, 158, 0.1)',
                      border: userStakeInfo?.active 
                        ? '1px solid rgba(76, 175, 80, 0.2)' 
                        : '1px solid rgba(158, 158, 158, 0.2)',
                      borderRadius: 2,
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1 }}>
                      <AccountBalance sx={{ 
                        color: userStakeInfo?.active ? 'success.main' : 'text.secondary', 
                        mr: 1, 
                        fontSize: 20 
                      }} />
                      <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                        Status
                      </Typography>
                    </Box>
                    <Chip
                      label={userStakeInfo?.active ? 'Staking' : 'Not Staking'}
                      color={userStakeInfo?.active ? 'success' : 'default'}
                      sx={{ 
                        fontWeight: 'bold',
                        fontSize: '0.9rem',
                        height: 32,
                        '& .MuiChip-label': {
                          px: 2,
                        }
                      }}
                    />
                  </Paper>
                </Grid>
              </Grid>

              {/* Daily Reward Info */}
              {userStakeInfo?.active && (
                <Box sx={{ mt: 3 }}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 2, 
                      textAlign: 'center',
                      background: 'rgba(0, 123, 255, 0.1)',
                      border: '1px solid rgba(0, 123, 255, 0.2)',
                      borderRadius: 2,
                    }}
                  >
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontWeight: 500 }}>
                      Daily Reward Rate
                    </Typography>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        fontWeight: 700,
                        color: 'primary.main',
                        fontFamily: 'monospace',
                      }}
                    >
                      ${parseFloat(userStakeInfo.dailyReward).toFixed(2)} USDT
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ opacity: 0.7 }}>
                      Earned daily at current rate
                    </Typography>
                  </Paper>
                </Box>
              )}
            </>
          ) : (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <AccountBalanceWallet sx={{ fontSize: 48, color: 'text.secondary', mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
                Connect Your Wallet
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ opacity: 0.7 }}>
                View your staking dashboard and manage your investments
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Claim Button */}
      {isConnected && userStakeInfo?.claimableRewards && parseFloat(userStakeInfo.claimableRewards) > 0 && (
        <Box sx={{ mb: 3 }}>
          <Button
            variant="contained"
            color="success"
            fullWidth
            size="large"
            onClick={handleClaim}
            disabled={loading}
            sx={{ fontWeight: 'bold', py: 1.5 }}
          >
            {loading ? (
              <CircularProgress size={24} color="inherit" />
            ) : (
              `CLAIM ${parseFloat(userStakeInfo.claimableRewards).toFixed(6)} AIM REWARDS`
            )}
          </Button>
        </Box>
      )}

      {/* Staking Plans */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', textAlign: 'center' }}>
            STAKE PLANS
          </Typography>
          {stakingPlans.length > 0 ? (
            stakingPlans.map((plan, index) => (
              <Card
                key={index}
                sx={{
                  mb: 2,
                  border: selectedPlan === index ? '2px solid' : '1px solid',
                  borderColor: selectedPlan === index ? 'primary.main' : 'rgba(255, 255, 255, 0.1)',
                  background: selectedPlan === index ? 'rgba(183, 4, 219, 0.1)' : 'transparent',
                  cursor: userStakeInfo?.active ? 'not-allowed' : 'pointer',
                  opacity: userStakeInfo?.active ? 0.6 : 1,
                }}
                onClick={() => {
                  if (!userStakeInfo?.active) {
                    console.log('🔍 Plan selected:', index);
                    setSelectedPlan(index);
                  }
                }}
              >
                <CardContent sx={{ py: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                    <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                      Plan {index + 1}
                    </Typography>
                    <Chip
                      label={`${plan.totalReturn}% Return`}
                      color="primary"
                      size="small"
                    />
                  </Box>
                  <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <AccessTime fontSize="small" />
                      <Typography variant="body2">{plan.duration} Days</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <TrendingUp fontSize="small" />
                      <Typography variant="body2">Daily USDT Rewards</Typography>
                    </Box>
                  </Box>
                  {selectedPlan === index && !userStakeInfo?.active && (
                    <Box>
                      <Divider sx={{ my: 1 }} />
                      <Typography variant="body2" sx={{ mb: 1, fontWeight: 'bold' }}>
                        Select Amount:
                      </Typography>
                      <Grid container spacing={1}>
                        {plan.amounts.map((amount, amountIndex) => (
                          <Grid item xs={4} key={amountIndex}>
                            <Button
                              variant={selectedAmount === amount ? 'contained' : 'outlined'}
                              color="primary"
                              fullWidth
                              size="small"
                              onClick={(e) => {
                                e.stopPropagation();
                                console.log('🔍 Amount selected:', amount);
                                console.log('🔍 Amount type:', typeof amount);
                                setSelectedAmount(amount);
                              }}
                            >
                              ${parseFloat(amount).toFixed(0)}
                            </Button>
                          </Grid>
                        ))}
                      </Grid>
                      {selectedAmount && (
                        <Box sx={{ mt: 1, p: 1, backgroundColor: 'rgba(0, 123, 255, 0.1)', borderRadius: 1 }}>
                          <Typography variant="body2" color="secondary">
                            Daily Reward: ${parseFloat(getSelectedAmountReward() || '0').toFixed(2)} USDT
                          </Typography>
                        </Box>
                      )}
                    </Box>
                  )}
                  {userStakeInfo?.active && (
                    <Box sx={{ mt: 1, p: 1, backgroundColor: 'rgba(255, 193, 7, 0.1)', borderRadius: 1 }}>
                      <Typography variant="body2" color="warning.main">
                        You already have an active stake. Complete it before starting a new one.
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Box sx={{ textAlign: 'center', py: 2 }}>
              <Typography variant="body2" color="text.secondary">
                Loading staking plans...
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Stake Button */}
      <Button
        variant="contained"
        color="primary"
        fullWidth
        size="large"
        onClick={handleStake}
        disabled={!selectedAmount || selectedPlan === null || loading || userStakeInfo?.active}
        sx={{ mb: 3, fontWeight: 'bold', py: 1.5 }}
      >
        {loading ? (
          <CircularProgress size={24} color="inherit" />
        ) : userStakeInfo?.active ? (
          'STAKE ACTIVE - COMPLETE CURRENT STAKE FIRST'
        ) : (
          `STAKE ${selectedAmount ? `$${parseFloat(selectedAmount).toFixed(0)} USDT` : ''}`
        )}
      </Button>

      {/* Balance Info */}
      {isConnected && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Your Balances
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                    {parseFloat(bnbBalance).toFixed(4)}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    BNB
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                    {parseFloat(usdtBalance).toFixed(2)}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    USDT
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                    {parseFloat(aimBalance).toFixed(2)}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    AIM
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      )}

      {/* AIM Swap Widget */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: 1 }}>
            <SwapHoriz />
            AIM Swap
          </Typography>
          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              Current AIM Price: ${aimPrice.toFixed(6)}
              {priceInfo.pairExists && priceInfo.usingPancakeSwap && (
                <Chip label="Live" color="success" size="small" sx={{ ml: 1 }} />
              )}
            </Typography>
          </Box>
          <Button
            variant="outlined"
            color="secondary"
            fullWidth
            href="https://pancakeswap.finance/swap"
            target="_blank"
            sx={{ mb: 1 }}
          >
            Swap BNB to AIM on PancakeSwap
          </Button>
          <Button
            variant="outlined"
            color="secondary"
            fullWidth
            href="https://pancakeswap.finance/swap"
            target="_blank"
          >
            Swap USDT to AIM on PancakeSwap
          </Button>
        </CardContent>
      </Card>

      {/* Confirmation Dialogs */}
      <Dialog open={confirmDialog} onClose={() => setConfirmDialog(false)}>
        <DialogTitle>Confirm Staking</DialogTitle>
        <DialogContent>
          <Typography variant="body1" sx={{ mb: 2 }}>
            You are about to stake <strong>${selectedAmount} USDT</strong> in <strong>Plan {selectedPlan !== null ? selectedPlan + 1 : ''}</strong>
          </Typography>
          {getSelectedPlanData() && (
            <>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                • Duration: {getSelectedPlanData()?.duration} days
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                • Daily Reward: ${parseFloat(getSelectedAmountReward() || '0').toFixed(2)} USDT
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                • Total Return: {getSelectedPlanData()?.totalReturn}%
              </Typography>
            </>
          )}
          <Typography variant="body2" color="warning.main">
            Note: 50% of staked USDT goes to fee receiver, staked USDT cannot be reclaimed. Rewards are distributed in AIM tokens.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialog(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleConfirmStake} variant="contained" color="primary" disabled={loading}>
            {loading ? <CircularProgress size={20} /> : 'Confirm Stake'}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={claimDialog} onClose={() => setClaimDialog(false)}>
        <DialogTitle>Confirm Claim</DialogTitle>
        <DialogContent>
          <Typography variant="body1" sx={{ mb: 2 }}>
            You are about to claim <strong>{userStakeInfo?.claimableRewards ? parseFloat(userStakeInfo.claimableRewards).toFixed(6) : '0.000000'} AIM</strong> rewards.
          </Typography>
          <Typography variant="body2" color="warning.main">
            A 5% fee will be deducted from your claim amount.
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            You will receive: {userStakeInfo?.claimableRewards ? (parseFloat(userStakeInfo.claimableRewards) * 0.95).toFixed(6) : '0.000000'} AIM tokens
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setClaimDialog(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleConfirmClaim} variant="contained" color="success" disabled={loading}>
            {loading ? <CircularProgress size={20} /> : 'Confirm Claim'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Fund AIM Tokens Dialog */}
      <Dialog open={fundDialog} onClose={() => setFundDialog(false)}>
        <DialogTitle>Fund AIM Tokens</DialogTitle>
        <DialogContent>
          <Typography variant="body1" sx={{ mb: 2 }}>
            Fund the contract with AIM tokens to ensure sufficient rewards for stakers.
          </Typography>
          <TextField
            fullWidth
            label="Amount to Fund"
            type="number"
            value={fundAmount}
            onChange={(e) => setFundAmount(e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">AIM</InputAdornment>,
            }}
            sx={{ mb: 2 }}
          />
          <Typography variant="body2" color="text.secondary">
            Your AIM Balance: {parseFloat(aimBalance).toFixed(2)} AIM
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Contract Balance: {parseFloat(aimFundingInfo.contractBalance).toFixed(2)} AIM
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setFundDialog(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleFundTokens} variant="contained" color="primary" disabled={loading}>
            {loading ? <CircularProgress size={20} /> : 'Fund Tokens'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Withdraw AIM Tokens Dialog (Owner Only) */}
      {isOwner && (
        <Dialog open={withdrawDialog} onClose={() => setWithdrawDialog(false)}>
          <DialogTitle>Withdraw AIM Tokens</DialogTitle>
          <DialogContent>
            <Typography variant="body1" sx={{ mb: 2 }}>
              Withdraw AIM tokens from the contract (Owner only).
            </Typography>
            <TextField
              fullWidth
              label="Amount to Withdraw"
              type="number"
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              InputProps={{
                endAdornment: <InputAdornment position="end">AIM</InputAdornment>,
              }}
              sx={{ mb: 2 }}
            />
            <Typography variant="body2" color="text.secondary">
              Contract Balance: {parseFloat(aimFundingInfo.contractBalance).toFixed(2)} AIM
            </Typography>
            <Typography variant="body2" color="warning.main">
              Warning: Ensure sufficient tokens remain for pending rewards!
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setWithdrawDialog(false)} disabled={loading}>
              Cancel
            </Button>
            <Button onClick={handleWithdrawTokens} variant="contained" color="secondary" disabled={loading}>
              {loading ? <CircularProgress size={20} /> : 'Withdraw Tokens'}
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </Container>
  );
};

export default Stake;