// ABI definitions for smart contracts
export const ERC20_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function transferFrom(address from, address to, uint256 amount) returns (bool)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function name() view returns (string)"
];

export const AIM_STAKING_ABI = [
  // View functions
  "function stakingPlans(uint256) view returns (uint256 duration, uint256 totalReturn, bool active, uint256[] amounts, uint256[] dailyRewards)",
  "function userStakes(address) view returns (uint256 planId, uint256 amount, uint256 startTime, uint256 lastClaimTime, uint256 dailyReward, bool active, bool holdBonus)",
  "function referralData(address) view returns (address referrer, uint256 totalReferrals, uint256 totalEarnings)",
  "function totalPlans() view returns (uint256)",
  "function totalStaked() view returns (uint256)",
  "function totalUsers() view returns (uint256)",
  "function aimPriceInUSDT() view returns (uint256)",
  "function owner() view returns (address)",
  "function usePancakeSwapPrice() view returns (bool)",
  "function totalAimFunded() view returns (uint256)",
  "function totalAimDistributed() view returns (uint256)",
  "function getClaimableRewards(address user) view returns (uint256)",
  "function isStakeComplete(address user) view returns (bool)",
  "function getRemainingTime(address user) view returns (uint256)",
  "function getRealTimeAimPrice() view returns (uint256)",
  "function calculateAimTokens(uint256 usdtAmount) view returns (uint256)",
  "function getPriceInfo() view returns (uint256 realTimePrice, uint256 storedPrice, bool usingPancakeSwap, bool pairExists)",
  "function getAimFundingInfo() view returns (uint256 contractBalance, uint256 totalFunded, uint256 totalDistributed, uint256 availableForRewards)",
  "function hasSufficientAimTokens(uint256 usdtRewardAmount) view returns (bool)",
  "function estimateRequiredAimTokens() view returns (uint256)",
  "function getUserStakeInfo(address user) view returns (uint256 planId, uint256 amount, uint256 startTime, uint256 lastClaimTime, uint256 dailyReward, bool active, bool holdBonus, uint256 claimableRewards, uint256 remainingTime)",
  "function getReferralInfo(address user) view returns (address referrer, uint256 totalReferrals, uint256 totalEarnings)",
  "function getReferralLevelInfo(address user, uint256 level) view returns (uint256 referrals, uint256 earnings)",
  "function getStakingPlan(uint256 planId) view returns (uint256 duration, uint256 totalReturn, bool active, uint256[] amounts, uint256[] dailyRewards)",
  
  // State changing functions
  "function stake(uint256 planId, uint256 amount, address referrer)",
  "function claimRewards()",
  "function fundAimTokens(uint256 amount)",
  "function ownerFundAimTokens(uint256 amount)",
  "function updateAimPrice(uint256 newPrice)",
  "function togglePancakeSwapPrice(bool enabled)",
  "function updatePancakeRouter(address newRouter)",
  "function emergencyDisablePancakeSwap()",
  "function withdrawAIM(uint256 amount)",
  "function emergencyWithdrawToken(address token, uint256 amount)",
  
  // Events
  "event Staked(address indexed user, uint256 planId, uint256 amount, address referrer)",
  "event Claimed(address indexed user, uint256 amount, uint256 fee)",
  "event ReferralPaid(address indexed referrer, address indexed referee, uint256 level, uint256 amount)",
  "event PriceUpdated(uint256 newPrice)",
  "event PancakeSwapToggled(bool enabled)",
  "event AimTokensFunded(address indexed funder, uint256 amount, uint256 totalFunded)",
  "event AimTokensWithdrawn(address indexed recipient, uint256 amount)",
  "event EmergencyWithdrawal(address indexed token, address indexed recipient, uint256 amount)"
];

export const PANCAKESWAP_ROUTER_V2_ABI = [
  "function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts)",
  "function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts)",
  "function factory() external pure returns (address)",
  "function WETH() external pure returns (address)"
];

export const PANCAKESWAP_FACTORY_ABI = [
  "function getPair(address tokenA, address tokenB) external view returns (address pair)"
];

export const PANCAKESWAP_PAIR_ABI = [
  "function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)",
  "function token0() external view returns (address)",
  "function token1() external view returns (address)"
];