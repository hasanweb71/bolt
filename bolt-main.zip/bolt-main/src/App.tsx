import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Box } from '@mui/material';
import Header from './components/Header';
import BottomNavigation from './components/BottomNavigation';
import Home from './pages/Home';
import Referrals from './pages/Referrals';
import Stake from './pages/Stake';
import Income from './pages/Income';
import PlayToEarn from './pages/PlayToEarn';
import { Web3Provider } from './contexts/Web3Context';

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#b704db',
      light: '#d647f0',
      dark: '#8a0399',
    },
    secondary: {
      main: '#007BFF',
      light: '#4da3ff',
      dark: '#0056b3',
    },
    background: {
      default: '#0a0a0a',
      paper: '#1a1a1a',
    },
    success: {
      main: '#4caf50',
    },
    error: {
      main: '#f44336',
    },
    text: {
      primary: '#ffffff',
      secondary: '#b0b0b0',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 500,
    },
  },
  shape: {
    borderRadius: 12,
  },
});

function App() {
  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <Web3Provider>
        <Router>
          <Box sx={{ 
            minHeight: '100vh', 
            backgroundColor: 'background.default',
            pb: 8 // Bottom padding for navigation
          }}>
            <Header />
            <Box sx={{ pt: 8 }}> {/* Top padding for header */}
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/referrals" element={<Referrals />} />
                <Route path="/stake" element={<Stake />} />
                <Route path="/income" element={<Income />} />
                <Route path="/play2earn" element={<PlayToEarn />} />
              </Routes>
            </Box>
            <BottomNavigation />
          </Box>
        </Router>
      </Web3Provider>
    </ThemeProvider>
  );
}

export default App;