import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  BottomNavigation as MuiBottomNavigation,
  BottomNavigationAction,
  Paper,
  Box,
  Typography,
  Container,
} from '@mui/material';
import {
  Home,
  Group,
  AccountBalance,
  TrendingUp,
  SportsEsports,
} from '@mui/icons-material';

const BottomNavigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const getValue = () => {
    switch (location.pathname) {
      case '/':
        return 0;
      case '/referrals':
        return 1;
      case '/stake':
        return 2;
      case '/income':
        return 3;
      case '/play2earn':
        return 4;
      default:
        return 0;
    }
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    switch (newValue) {
      case 0:
        navigate('/');
        break;
      case 1:
        navigate('/referrals');
        break;
      case 2:
        navigate('/stake');
        break;
      case 3:
        navigate('/income');
        break;
      case 4:
        navigate('/play2earn');
        break;
    }
  };

  const navigationItems = [
    { label: 'Home', icon: <Home />, path: '/' },
    { label: 'Referrals', icon: <Group />, path: '/referrals' },
    { label: 'Stake', icon: <AccountBalance />, path: '/stake' },
    { label: 'Income', icon: <TrendingUp />, path: '/income' },
    { label: 'Play2Earn', icon: <SportsEsports />, path: '/play2earn' },
  ];

  return (
    <Paper
      sx={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        background: 'linear-gradient(45deg, #1a1a1a 30%, #2a2a2a 90%)',
        backdropFilter: 'blur(10px)',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)',
        pb: 0.5, // Reduced from 1
      }}
      elevation={3}
    >
      <Container maxWidth="sm" sx={{ px: 0 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center', pt: 0.5, px: 2 }}> {/* Reduced pt from 1 to 0.5 */}
          {navigationItems.map((item, index) => {
            const isActive = getValue() === index;
            const isStake = item.path === '/stake';
            
            return (
              <Box
                key={item.path}
                onClick={() => handleChange({} as React.SyntheticEvent, index)}
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  cursor: 'pointer',
                  py: 0.5, // Reduced from 1
                  px: 1.5, // Reduced from 2
                  borderRadius: 2,
                  minWidth: 50, // Reduced from 60
                  background: isStake && isActive 
                    ? 'linear-gradient(45deg, #b704db, #007BFF)' 
                    : isStake 
                      ? 'linear-gradient(45deg, rgba(183, 4, 219, 0.2), rgba(0, 123, 255, 0.2))'
                      : 'transparent',
                  border: isStake ? '1px solid rgba(183, 4, 219, 0.5)' : 'none',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    background: isStake 
                      ? 'linear-gradient(45deg, #b704db, #007BFF)' 
                      : 'rgba(255, 255, 255, 0.05)',
                    transform: 'translateY(-1px)', // Reduced from -2px
                  },
                }}
              >
                <Box
                  sx={{
                    color: isActive 
                      ? isStake 
                        ? '#ffffff' 
                        : 'primary.main'
                      : isStake
                        ? 'primary.main'
                        : 'text.secondary',
                    mb: 0.25, // Reduced from 0.5
                    fontSize: isStake ? 24 : 20, // Reduced from 28:24
                    transition: 'all 0.3s ease',
                  }}
                >
                  {item.icon}
                </Box>
                <Typography
                  variant="caption"
                  sx={{
                    color: isActive 
                      ? isStake 
                        ? '#ffffff' 
                        : 'primary.main'
                      : isStake
                        ? 'primary.main'
                        : 'text.secondary',
                    fontWeight: isActive || isStake ? 'bold' : 'normal',
                    fontSize: isStake ? '0.7rem' : '0.65rem', // Reduced from 0.8rem:0.7rem
                    textAlign: 'center',
                    lineHeight: 1,
                  }}
                >
                  {item.label}
                </Typography>
              </Box>
            );
          })}
        </Box>
      </Container>
    </Paper>
  );
};

export default BottomNavigation;