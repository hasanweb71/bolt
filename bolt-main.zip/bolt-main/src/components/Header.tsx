import React from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Chip,
  IconButton,
  Menu,
  MenuItem,
  Container,
  Tooltip,
  Switch,
  FormControlLabel,
} from '@mui/material';
import {
  AccountBalanceWallet,
  ContentCopy,
  ExitToApp,
  Refresh,
  Warning,
  CheckCircle,
  Settings,
} from '@mui/icons-material';
import { useWeb3 } from '../contexts/Web3Context';

const Header: React.FC = () => {
  const { 
    account, 
    aimPrice, 
    priceInfo, 
    isConnected, 
    connectWallet, 
    disconnectWallet, 
    updateContractAimPrice, 
    togglePancakeSwapPrice,
    loading, 
    isOwner 
  } = useWeb3();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleCopyAddress = () => {
    if (account) {
      navigator.clipboard.writeText(account);
      alert('Address copied to clipboard!');
    }
    handleMenuClose();
  };

  const handleDisconnect = () => {
    disconnectWallet();
    handleMenuClose();
  };

  const handleUpdatePrice = async () => {
    try {
      await updateContractAimPrice();
      alert('Contract price updated successfully!');
    } catch (error: any) {
      alert(`Failed to update price: ${error.message}`);
    }
    handleMenuClose();
  };

  const handleTogglePancakeSwap = async () => {
    try {
      await togglePancakeSwapPrice(!priceInfo.usingPancakeSwap);
      alert(`PancakeSwap pricing ${!priceInfo.usingPancakeSwap ? 'enabled' : 'disabled'} successfully!`);
    } catch (error: any) {
      alert(`Failed to toggle PancakeSwap pricing: ${error.message}`);
    }
    handleMenuClose();
  };

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const getPriceStatus = () => {
    if (!priceInfo.usingPancakeSwap) {
      return { icon: <Warning fontSize="small" />, color: 'warning', tooltip: 'Using fallback price - PancakeSwap integration disabled' };
    }
    
    if (!priceInfo.pairExists) {
      return { icon: <Warning fontSize="small" />, color: 'warning', tooltip: 'No trading pair found - using fallback price' };
    }
    
    const priceDiff = Math.abs(priceInfo.realTimePrice - priceInfo.contractPrice);
    const diffPercentage = (priceDiff / priceInfo.realTimePrice) * 100;
    
    if (diffPercentage > 5) {
      return { icon: <Warning fontSize="small" />, color: 'warning', tooltip: 'Contract price differs significantly from market price' };
    }
    
    return { icon: <CheckCircle fontSize="small" />, color: 'success', tooltip: 'Price is up to date' };
  };

  const priceStatus = getPriceStatus();

  return (
    <AppBar 
      position="fixed" 
      sx={{ 
        background: 'linear-gradient(45deg, #1a1a1a 30%, #2a2a2a 90%)',
        backdropFilter: 'blur(10px)',
      }}
    >
      <Container maxWidth="sm" sx={{ px: 0 }}>
        <Toolbar sx={{ justifyContent: 'space-between', px: 2 }}>
          {/* Left: AIM Price */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Tooltip title={priceStatus.tooltip}>
              <Chip
                label={`AIM: $${aimPrice.toFixed(6)}`}
                color="secondary"
                size="small"
                sx={{ fontWeight: 'bold' }}
                icon={priceStatus.icon}
              />
            </Tooltip>
            {priceInfo.pairExists && priceInfo.usingPancakeSwap && (
              <Typography variant="caption" color="text.secondary">
                Live
              </Typography>
            )}
          </Box>

          {/* Center: Logo */}
          <Typography
            variant="h6"
            sx={{
              fontWeight: 'bold',
              background: 'linear-gradient(45deg, #b704db, #007BFF)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            AIM FINANCE
          </Typography>

          {/* Right: Wallet Connection */}
          <Box>
            {!isConnected ? (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AccountBalanceWallet />}
                onClick={connectWallet}
                size="small"
                sx={{ 
                  borderRadius: 20,
                  textTransform: 'none',
                  fontWeight: 'bold',
                }}
              >
                Connect
              </Button>
            ) : (
              <>
                <Button
                  variant="outlined"
                  color="secondary"
                  onClick={handleMenuOpen}
                  size="small"
                  sx={{ 
                    borderRadius: 20,
                    textTransform: 'none',
                    fontWeight: 'bold',
                  }}
                >
                  {truncateAddress(account!)}
                </Button>
                <Menu
                  anchorEl={anchorEl}
                  open={Boolean(anchorEl)}
                  onClose={handleMenuClose}
                  PaperProps={{
                    sx: {
                      backgroundColor: 'background.paper',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      minWidth: 250,
                    }
                  }}
                >
                  <MenuItem onClick={handleCopyAddress}>
                    <ContentCopy sx={{ mr: 1 }} fontSize="small" />
                    Copy Address
                  </MenuItem>
                  {isOwner && (
                    <>
                      <MenuItem onClick={handleUpdatePrice} disabled={loading}>
                        <Refresh sx={{ mr: 1 }} fontSize="small" />
                        Update Contract Price
                      </MenuItem>
                      <MenuItem onClick={handleTogglePancakeSwap} disabled={loading}>
                        <Settings sx={{ mr: 1 }} fontSize="small" />
                        {priceInfo.usingPancakeSwap ? 'Disable' : 'Enable'} PancakeSwap
                      </MenuItem>
                    </>
                  )}
                  <MenuItem onClick={handleDisconnect}>
                    <ExitToApp sx={{ mr: 1 }} fontSize="small" />
                    Disconnect
                  </MenuItem>
                </Menu>
              </>
            )}
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;